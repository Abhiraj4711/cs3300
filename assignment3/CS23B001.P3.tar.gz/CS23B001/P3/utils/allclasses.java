package utils;

import java.util.HashMap;

public class allclasses {
    public HashMap<String, classinfo> classes=new HashMap<>();
}
