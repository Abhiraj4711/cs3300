package utils;
import java.util.*;

public class LivenessAnalyzer {

    public HashSet<BBinfo> allStartingBBs = new HashSet<>();
    public HashSet<BBinfo> allEndingBBs = new HashSet<>();
    public ArrayList<BBinfo> allBBs = new ArrayList<>();

    public ArrayList<Map<Integer, int[]>> liveRanges = new ArrayList<>();

    public void computeLiveRanges() {
        int params=0;
        for (int i = 0; i < allBBs.size(); i++) {
            BBinfo bb = allBBs.get(i);
            if (allStartingBBs.contains(bb)) {
                liveRanges.add(new TreeMap<>());
                params = bb.params;
            }
            HashSet<String> livein = new HashSet<>();
            HashSet<String> liveout = new HashSet<>();
            livein.addAll(bb.def);
            liveout.addAll(bb.use);

            for (String var : livein) {
                if (Integer.parseInt(var) < params) {
                    continue;
                }
                liveRanges.get(liveRanges.size()-1).putIfAbsent(Integer.valueOf(var), new int[] { i+1, i+1 });
                int[] range = liveRanges.get(liveRanges.size()-1).get(Integer.valueOf(var));
                range[0] = Math.min(range[0], i + 1);
                range[1] = Math.max(range[1], i + 1);
            }
            for (String var : liveout) {
                if (Integer.parseInt(var) < params) {
                    continue;
                }
                liveRanges.get(liveRanges.size()-1).putIfAbsent(Integer.valueOf(var), new int[] { i+1, i+1 });
                liveRanges.get(liveRanges.size() - 1).get(Integer.valueOf(var))[1] = i + 1;
            }
        }
    }

    public void printLiveRanges() {
        for (int i = 0; i < liveRanges.size(); i++) {
            for (Map.Entry<Integer, int[]> e : liveRanges.get(i).entrySet()) {
                System.out.println(e.getKey() + " : " + e.getValue()[0] + " → " + e.getValue()[1]);
            }
        }
    }
}
